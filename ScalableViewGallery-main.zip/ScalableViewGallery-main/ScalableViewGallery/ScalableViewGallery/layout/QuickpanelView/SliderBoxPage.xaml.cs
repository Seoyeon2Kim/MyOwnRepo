﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class SliderBoxPage : View
    {
        private void ApplyUnitSize()
        {
            var height = MainView.HeightSpecification;
            MainView.HeightSpecification = height.ToPixel();

            height = BgSlider.HeightSpecification;
            BgSlider.HeightSpecification = height.ToPixel();

            height = BottomPadding.HeightSpecification;
            BottomPadding.HeightSpecification = height.ToPixel();
        }

        public SliderBoxPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
