﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class QuickSettingBoxPage : View
    {
        private void ApplyUnitSize()
        {
            var height = TopPadding.HeightSpecification;
            TopPadding.HeightSpecification = height.ToPixel();

            height = MiddlePadding.HeightSpecification;
            MiddlePadding.HeightSpecification = height.ToPixel();

            height = BottomPadding.HeightSpecification;
            BottomPadding.HeightSpecification = height.ToPixel();

            height = IconBox.HeightSpecification;
            IconBox.HeightSpecification = height.ToPixel();

            var width = Name.WidthSpecification;
            Name.WidthSpecification = width.ToPixel();

            // Text
            Name.PointSize = Name.PointSize.DpToPoint();
        }

        public QuickSettingBoxPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
