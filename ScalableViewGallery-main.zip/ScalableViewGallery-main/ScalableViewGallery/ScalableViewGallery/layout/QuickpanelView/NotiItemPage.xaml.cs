﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class NotiItemPage : View
    {
        private void ApplyUnitSize()
        {
            var height = MainView.HeightSpecification;
            MainView.HeightSpecification = height.ToPixel();

            // Text
            Icon.PointSize = Icon.PointSize.DpToPoint();
            Title.PointSize = Title.PointSize.DpToPoint();
            SubTitle.PointSize = SubTitle.PointSize.DpToPoint();
        }

        public NotiItemPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
