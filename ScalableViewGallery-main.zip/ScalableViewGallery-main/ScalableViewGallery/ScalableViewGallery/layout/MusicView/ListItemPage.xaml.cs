﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class ListItemPage : View
    {
        private void ApplyUnitSize()
        {
            Title.PointSize = Title.PointSize.DpToPoint();
            Author.PointSize = Author.PointSize.DpToPoint();
            PlayTime.PointSize= PlayTime.PointSize.DpToPoint();
        }

        public ListItemPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
