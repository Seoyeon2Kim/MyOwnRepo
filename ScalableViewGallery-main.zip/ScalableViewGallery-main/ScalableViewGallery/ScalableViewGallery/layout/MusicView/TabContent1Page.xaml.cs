﻿using System.Collections.Generic;
using Tizen.NUI.BaseComponents;
using Tizen.NUI;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class TabContent1Page : View
    {
        private readonly int ItemCount = 10;
        private List<ListItemPage> items;

        private void ApplyUnitSize()
        {
            Title.PointSize = Title.PointSize.DpToPoint();
            Author.PointSize = Author.PointSize.DpToPoint();
            TrackCount.PointSize = TrackCount.PointSize.DpToPoint();
        }

        public TabContent1Page()
        {
            InitializeComponent();

            ApplyUnitSize();

            items = new List<ListItemPage>();

            for (int i = 0; i < ItemCount; ++i)
            {
                ListItemPage listItemPage = new ListItemPage();
                items.Add(listItemPage);
                Scoller.Add(items[i]);
            }

            TrackCount.Text = ItemCount.ToString() + " tracks";
        }
    }
}
