﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.GalleryView
{
    public partial class PhotoContentPage : View
    {
        private void ApplyUnitSize()
        {
            var height = TitleBox1.HeightSpecification;
            TitleBox1.HeightSpecification = height.ToPixel();
            height = TitleBox2.HeightSpecification;
            TitleBox2.HeightSpecification = height.ToPixel();
            height = TitleBox3.HeightSpecification;
            TitleBox3.HeightSpecification = height.ToPixel();

            var width = TitleBox1LeftPadding.WidthSpecification;
            TitleBox1LeftPadding.WidthSpecification = width.ToPixel();
            width = TitleBox2LeftPadding.WidthSpecification;
            TitleBox2LeftPadding.WidthSpecification = width.ToPixel();
            width = TitleBox3LeftPadding.WidthSpecification;
            TitleBox3LeftPadding.WidthSpecification = width.ToPixel();

            Title1.PointSize = Title1.PointSize.DpToPoint();
            Title2.PointSize = Title2.PointSize.DpToPoint();
            Title3.PointSize = Title3.PointSize.DpToPoint();
        }

        public PhotoContentPage()
        {
            InitializeComponent();

            ApplyUnitSize();

            for (int i = 0; i < 10; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox1.Add(imageBoxPage);
            }

            for (int i = 0; i < 8; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox2.Add(imageBoxPage);
            }

            for (int i = 0; i < 2; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox3.Add(imageBoxPage);
            }

        }
    }
}
