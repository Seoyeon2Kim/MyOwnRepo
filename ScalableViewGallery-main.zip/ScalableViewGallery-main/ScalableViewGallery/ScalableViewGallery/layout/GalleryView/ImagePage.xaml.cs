﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.GalleryView
{
    public partial class ImagePage : View
    {
        public ImagePage()
        {
            InitializeComponent();
        }
    }
}
