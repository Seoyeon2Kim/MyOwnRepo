﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.GalleryView
{
    public partial class GalleryViewPage : ContentPage
    {
        private void ApplyUnitSize()
        {
            var height = Top.HeightSpecification;
            Top.HeightSpecification = height.ToPixel();
        }

        private void CreateTabView()
        {
            TabView tabView = new TabView()
            {
                WidthSpecification = LayoutParamPolicies.MatchParent,
                HeightSpecification = LayoutParamPolicies.MatchParent,
            };

            int tabCount = 0;
            TabButton tabButton;
            View tabContent;

            for (int i = 1; i < 3; ++i)
            {
                tabButton = new TabButton()
                {
                    Text = "Tab" + i.ToString(),
                    PointSize = 25.0f.DpToPoint(),
                };

                tabContent = new View()
                {
                    // Text = "Content" + i.ToString(),
                    BackgroundColor = Color.White,
                    WidthSpecification = LayoutParamPolicies.MatchParent,
                    HeightSpecification = LayoutParamPolicies.MatchParent,
                    //HorizontalAlignment = HorizontalAlignment.Center,
                    //VerticalAlignment = VerticalAlignment.Center,
                };

                tabView.AddTab(tabButton, tabContent);
                tabCount++;

                if (i == 1)
                {
                    // tabContent가 TextLable로 Layout 설정이 되어있기 때문에 다시 Layout 설정을 한 번 해줘야 한다 (수정 예정)
                    //LinearLayout linearLayout = new LinearLayout();
                    //linearLayout.LinearOrientation = LinearLayout.Orientation.Horizontal;
                    //linearLayout.LinearAlignment = LinearLayout.Alignment.Begin;
                    //tabContent.Layout = linearLayout;

                    PhotoContentPage photoContentPage = new PhotoContentPage();
                    tabContent.Add(photoContentPage);
                }
            }
            Content.Add(tabView);
        }

        public GalleryViewPage()
        {
            InitializeComponent();

            ApplyUnitSize();

            CreateTabView();
        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }

    }
}
