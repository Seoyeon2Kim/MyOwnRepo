﻿
namespace ScalableViewGallery
{
    interface IExample
    {
        void Activate();
        void Deactivate();
    }
}
