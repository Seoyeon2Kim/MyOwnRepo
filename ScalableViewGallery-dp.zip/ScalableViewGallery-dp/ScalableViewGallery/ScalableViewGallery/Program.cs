﻿using System;
using Tizen.NUI;

namespace ScalableViewGallery
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            ScalableViewGallery Instance = new ScalableViewGallery();
            Instance.Run(args);
        }
    }
}
