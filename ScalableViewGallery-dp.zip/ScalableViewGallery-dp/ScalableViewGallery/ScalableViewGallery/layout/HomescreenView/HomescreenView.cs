﻿using Tizen.NUI;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.HomescreenView
{
    internal class HomescreenView : IExample
    {
        private Window window;
        private HomescreenViewPage page;

        public void Activate()
        {
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Activate()");

            window = NUIApplication.GetDefaultWindow();
            page = new HomescreenViewPage();

            /* navigator를 쓰기 위해서 page를 View가 아니라 ContentPage로 작업함 */
            //window.GetDefaultNavigator().Push(page);

            window.Add(page);
        }

        public void Deactivate()
        {
            Logger.Debug($"@@@ this.GetType().Name={this.GetType().Name}, Deactivate()");

            //window.GetDefaultNavigator().Pop();
            //page = null;

            page.Unparent();
            page.Dispose();
        }
    }
}
