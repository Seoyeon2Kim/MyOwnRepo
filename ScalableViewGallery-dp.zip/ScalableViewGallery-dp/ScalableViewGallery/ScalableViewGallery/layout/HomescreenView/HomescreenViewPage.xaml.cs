﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;

namespace ScalableViewGallery.layout.HomescreenView
{
    public partial class HomescreenViewPage : ContentPage
    {
        private const int BoxSize = 192;

        private void ApplyUnitSize()
        {
            var height = Top.HeightSpecification;
            Top.HeightSpecification = height.DpToPx();

            Icon1.PointSize = Icon1.PointSize.DpToPt();
            Icon2.PointSize = Icon2.PointSize.DpToPt();
            Icon3.PointSize = Icon3.PointSize.DpToPt();
            Icon4.PointSize = Icon4.PointSize.DpToPt();

            Time.PointSize = Time.PointSize.DpToPt();
        }


        //private Color GetColor(int index)
        //{
        //    Color color = new Color();
        //    switch (index)
        //    {
        //        case 0:
        //            color = new Color(0.749f, 0.243f, 1.0f, 1.0f);
        //            break;
        //        case 1:
        //            color = new Color(0.82f, 0.675f, 0.886f, 1.0f);
        //            break;
        //        case 2:
        //            color = new Color(0.918f, 0.753f, 0.839f, 1.0f);
        //            break;
        //        case 3:
        //            color = new Color(0.792f, 0.882f, 1.0f, 1.0f);
        //            break;
        //        case 4:
        //            color = new Color(0.518f, 0.439f, 1.0f, 1.0f);
        //            break;
        //    }
        //    return color;
        //}

        private string GetResourceUrl(int index)
        {
            string str = "";
            switch (index)
            {
                case 0:
                    str = "*Resource*/images/HomescreenView/browser.png";
                    break;
                case 1:
                    str = "*Resource*/images/HomescreenView/calendar.png";
                    break;
                case 2:
                    str = "*Resource*/images/HomescreenView/map.png";
                    break;
                case 3:
                    str = "*Resource*/images/HomescreenView/internet.png";
                    break;
            }
            return str;
        }

        private string GetNameText(int index)
        {
            string str = "";
            switch (index)
            {
                case 0:
                    str = "Browser";
                    break;
                case 1:
                    str = "Calendar";
                    break;
                case 2:
                    str = "Map";
                    break;
                case 3:
                    str = "Internet";
                    break;
            }
            return str;
        }

        private void CreateBoxes(int count)
        {
            for (int i = 0; i < count; ++i)
            {
                IconBoxPage iconBoxPage = new IconBoxPage();
                iconBoxPage.Icon.ResourceUrl = GetResourceUrl(i % 4);
                iconBoxPage.Name.Text = GetNameText(i % 4);
                Scroller.Add(iconBoxPage);
            }

            // Empty box : Boxes for setting the array of last row to left alignment
            // Number of the empty box can be changed
            for (int i = 0; i < 10; ++i)
            {
                View emptyBox = new View();
                emptyBox.WidthSpecification = BoxSize;
                emptyBox.HeightSpecification = 0;
                Scroller.Add(emptyBox);
            }
        }

        public HomescreenViewPage()
        {
            InitializeComponent();

            ApplyUnitSize();

            Scroller.ScrollDragStarted += OnScrollDragStarted;

            CreateBoxes(14);
        }

        private void OnScrollDragStarted(object sender, ScrollEventArgs args)
        {
            Logger.Debug("Dragging");
        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }
    }
}
