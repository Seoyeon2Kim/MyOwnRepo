﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.HomescreenView
{
    public partial class IconBoxPage : View
    {
        private void ApplyUnitSize()
        {
            Name.PointSize = Name.PointSize.DpToPt();
        }

        public IconBoxPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
