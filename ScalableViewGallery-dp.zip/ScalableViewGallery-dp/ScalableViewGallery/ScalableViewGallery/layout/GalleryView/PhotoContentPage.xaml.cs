﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.GalleryView
{
    public partial class PhotoContentPage : View
    {
        private void ApplyUnitSize()
        {
            var height = TitleBox1.HeightSpecification;
            TitleBox1.HeightSpecification = height.DpToPx();
            height = TitleBox2.HeightSpecification;
            TitleBox2.HeightSpecification = height.DpToPx();
            height = TitleBox3.HeightSpecification;
            TitleBox3.HeightSpecification = height.DpToPx();

            var width = TitleBox1LeftPadding.WidthSpecification;
            TitleBox1LeftPadding.WidthSpecification = width.DpToPx();
            width = TitleBox2LeftPadding.WidthSpecification;
            TitleBox2LeftPadding.WidthSpecification = width.DpToPx();
            width = TitleBox3LeftPadding.WidthSpecification;
            TitleBox3LeftPadding.WidthSpecification = width.DpToPx();

            Title1.PointSize = Title1.PointSize.DpToPt();
            Title2.PointSize = Title2.PointSize.DpToPt();
            Title3.PointSize = Title3.PointSize.DpToPt();
        }

        public PhotoContentPage()
        {
            InitializeComponent();

            ApplyUnitSize();

            for (int i = 0; i < 10; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox1.Add(imageBoxPage);
            }

            for (int i = 0; i < 8; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox2.Add(imageBoxPage);
            }

            for (int i = 0; i < 2; ++i)
            {
                ImagePage imageBoxPage = new ImagePage();
                ImageBox3.Add(imageBoxPage);
            }

        }
    }
}
