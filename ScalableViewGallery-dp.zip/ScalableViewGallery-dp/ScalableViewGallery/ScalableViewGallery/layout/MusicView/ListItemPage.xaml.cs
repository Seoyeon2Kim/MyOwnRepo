﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.MusicView
{
    public partial class ListItemPage : View
    {
        private void ApplyUnitSize()
        {
            Title.PointSize = Title.PointSize.DpToPt();
            Author.PointSize = Author.PointSize.DpToPt();
            PlayTime.PointSize= PlayTime.PointSize.DpToPt();
        }

        public ListItemPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
