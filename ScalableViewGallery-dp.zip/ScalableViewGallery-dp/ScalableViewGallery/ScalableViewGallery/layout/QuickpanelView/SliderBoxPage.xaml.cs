﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class SliderBoxPage : View
    {
        private void ApplyUnitSize()
        {
            var height = MainView.HeightSpecification;
            MainView.HeightSpecification = height.DpToPx();

            height = BgSlider.HeightSpecification;
            BgSlider.HeightSpecification = height.DpToPx();

            height = BottomPadding.HeightSpecification;
            BottomPadding.HeightSpecification = height.DpToPx();
        }

        public SliderBoxPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
