﻿using System.Collections.Generic;
using Tizen.NUI;
using Tizen.NUI.BaseComponents;
using Tizen.NUI.Components;
// CollectionView 사용 시 필요
using Tizen.NUI.Binding;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class QuickpanelViewPage : ContentPage
    {
        private void ApplyUnitSize()
        {
            var height = Top.HeightSpecification;
            Top.HeightSpecification = height.DpToPx();

            // Sliders
            height = Sliders.HeightSpecification;
            Sliders.HeightSpecification = height.DpToPx();

            // NotiView
            height = NotiTop.HeightSpecification;
            NotiTop.HeightSpecification = height.DpToPx();

            var width = NotiTopLeftPadding.WidthSpecification;
            NotiTopLeftPadding.WidthSpecification = width.DpToPx();

            width = NotiTopRightPadding.WidthSpecification;
            NotiTopRightPadding.WidthSpecification = width.DpToPx();

            // Bottom
            height = Bottom.HeightSpecification;
            Bottom.HeightSpecification = height.DpToPx();

            // Text
            Time.PointSize = Time.PointSize.DpToPt();
            Icon1.PointSize = Icon1.PointSize.DpToPt();
            Icon2.PointSize = Icon2.PointSize.DpToPt();
            Icon3.PointSize = Icon3.PointSize.DpToPt();
            Icon4.PointSize = Icon4.PointSize.DpToPt();
            NotiNum.PointSize = NotiNum.PointSize.DpToPt();
            NotiSettings.PointSize = NotiSettings.PointSize.DpToPt();
            Clear.PointSize = Clear.PointSize.DpToPt();
        }

        //private void CreateColView()
        //{
        //    BindingContext = new TestSourceModel(10);

        //    ColView.ItemTemplate = new DataTemplate(() =>
        //    {
        //        var item = new DefaultLinearItem()
        //        {
        //            WidthSpecification = LayoutParamPolicies.MatchParent,
        //        };
        //        item.Label.SetBinding(TextLabel.TextProperty, "Name");

        //        var icon = new View()
        //        {
        //            WidthSpecification = 60,
        //            HeightSpecification = 60
        //        };
        //        icon.SetBinding(BackgroundColorProperty, "BgColor");
        //        item.Icon = icon;

        //        return item;
        //    });
        //}

        private string GetQuickSettingResource(int index)
        {
            string str = "";
            switch (index)
            {
                case 0:
                    str = "*Resource*/images/QuickpanelView/wifi_off.png";
                    break;
                case 1:
                    str = "*Resource*/images/QuickpanelView/bluetooth_off.png";
                    break;
                case 2:
                    str = "*Resource*/images/QuickpanelView/soundon_off.png";
                    break;
                case 3:
                    str = "*Resource*/images/QuickpanelView/dnd_off.png";
                    break;
                case 4:
                    str = "*Resource*/images/QuickpanelView/softkey_off.png";
                    break;
                case 5:
                    str = "*Resource*/images/QuickpanelView/voice_off.png";
                    break;
            }
            return str;
        }

        private string GetQuickSettingNameText(int index)
        {
            string str = "";
            switch (index)
            {
                case 0:
                    str = "Wi-Fi";
                    break;
                case 1:
                    str = "Bluetooth";
                    break;
                case 2:
                    str = "Sound";
                    break;
                case 3:
                    str = "Do not disturb";
                    break;
                case 4:
                    str = "Soft keys";
                    break;
                case 5:
                    str = "Voice wake-up";
                    break;
            }
            return str;
        }

        private string GetSliderIconResourceUrl(int index)
        {
            string str = "";
            switch (index)
            {
                case 0:
                    str = "*Resource*/images/QuickpanelView/sound3_white.png";
                    break;
                case 1:
                    str = "*Resource*/images/QuickpanelView/brightness_full.png";
                    break;
            }
            return str;
        }

        private const int BoxSize = 175;

        private void CreateQuickSettingView(int count)
        {
            for (int i = 0; i < count; ++i)
            {
                QuickSettingBoxPage quickSettingBoxPage = new QuickSettingBoxPage();
                quickSettingBoxPage.Icon.ResourceUrl = GetQuickSettingResource(i);
                quickSettingBoxPage.Name.Text = GetQuickSettingNameText(i);
                QuickSettings.Add(quickSettingBoxPage);
            }

            // Empty box : Boxes for setting the array of last row to left alignment
            // Number of the empty box can be changed
            for (int i = 0; i < 10; ++i)
            {
                View emptyBox = new View();
                emptyBox.WidthSpecification = BoxSize.DpToPx();
                emptyBox.HeightSpecification = 0;
                Logger.Debug($"emptyBox w={emptyBox.WidthSpecification} h={emptyBox.HeightSpecification}");
                QuickSettings.Add(emptyBox);
            }
        }

        private void CreateSliderView()
        {
            View leftPadding = new View();
            leftPadding.WidthSpecification = 30.DpToPx(); // 임의로 정한 padding
            leftPadding.HeightSpecification = -1;
            Sliders.Add(leftPadding);

            SliderBoxPage volumeSlider = new SliderBoxPage();
            volumeSlider.Icon.ResourceUrl = GetSliderIconResourceUrl(0);
            Sliders.Add(volumeSlider);

            View middlePadding = new View();
            middlePadding.WidthSpecification = 50.DpToPx(); // 임의로 정한 padding
            middlePadding.HeightSpecification = -1;
            Sliders.Add(middlePadding);

            SliderBoxPage brightnessSlider = new SliderBoxPage();
            brightnessSlider.Icon.ResourceUrl = GetSliderIconResourceUrl(1);
            Sliders.Add(brightnessSlider);

            View rightPadding = new View();
            rightPadding.WidthSpecification = 30.DpToPx(); // 임의로 정한 padding
            rightPadding.HeightSpecification = -1;
            Sliders.Add(rightPadding);

            Logger.Debug($"leftPadding w={leftPadding.WidthSpecification} h={leftPadding.HeightSpecification}");
            Logger.Debug($"middlePadding w={middlePadding.WidthSpecification} h={middlePadding.HeightSpecification}");
            Logger.Debug($"rightPadding w={rightPadding.WidthSpecification} h={rightPadding.HeightSpecification}");
        }

        private readonly int ItemCount = 30;
        private List<NotiItemPage> items;

        private void CreateNotiList()
        {
            items = new List<NotiItemPage>();

            for (int i = 0; i < ItemCount; ++i)
            {
                NotiItemPage notiItemPage = new NotiItemPage();
                items.Add(notiItemPage);
                NotiScroller.Add(items[i]);
            }

            NotiNum.Text = "Notification(" + ItemCount.ToString() + ")";
        }

        public QuickpanelViewPage()
        {
            InitializeComponent();

            ApplyUnitSize();

            //CreateColView();
            CreateQuickSettingView(6);

            CreateSliderView();

            CreateNotiList();
        }

        protected override void Dispose(DisposeTypes type)
        {
            Logger.Debug("");
            if (Disposed)
            {
                return;
            }

            if (type == DisposeTypes.Explicit)
            {
                RemoveAllChildren(true);
            }

            base.Dispose(type);
        }

        private void RemoveAllChildren(bool dispose = false)
        {
            Logger.Debug("");
            RecursiveRemoveChildren(this, dispose);
        }

        private void RecursiveRemoveChildren(View parent, bool dispose)
        {
            Logger.Debug("");
            if (parent == null)
            {
                Logger.Debug("parent=null");
                return;
            }

            Logger.Debug("process remove child");
            int maxChild = (int)parent.ChildCount;
            for (int i = maxChild - 1; i >= 0; --i)
            {
                View child = parent.GetChildAt((uint)i);
                if (child == null)
                {
                    continue;
                }

                RecursiveRemoveChildren(child, dispose);
                parent.Remove(child);
                if (dispose)
                {
                    child.Dispose();
                }
            }
        }
    }
}
