﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class QuickSettingBoxPage : View
    {
        private void ApplyUnitSize()
        {
            var height = TopPadding.HeightSpecification;
            TopPadding.HeightSpecification = height.DpToPx();

            height = MiddlePadding.HeightSpecification;
            MiddlePadding.HeightSpecification = height.DpToPx();

            height = BottomPadding.HeightSpecification;
            BottomPadding.HeightSpecification = height.DpToPx();

            height = IconBox.HeightSpecification;
            IconBox.HeightSpecification = height.DpToPx();

            var width = Name.WidthSpecification;
            Name.WidthSpecification = width.DpToPx();

            // Text
            Name.PointSize = Name.PointSize.DpToPt();
        }

        public QuickSettingBoxPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
