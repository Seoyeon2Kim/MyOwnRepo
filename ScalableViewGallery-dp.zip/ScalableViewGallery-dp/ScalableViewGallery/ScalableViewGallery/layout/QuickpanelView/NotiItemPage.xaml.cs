﻿using Tizen.NUI;
using Tizen.NUI.BaseComponents;

namespace ScalableViewGallery.layout.QuickpanelView
{
    public partial class NotiItemPage : View
    {
        private void ApplyUnitSize()
        {
            var height = MainView.HeightSpecification;
            MainView.HeightSpecification = height.DpToPx();

            // Text
            Icon.PointSize = Icon.PointSize.DpToPt();
            Title.PointSize = Title.PointSize.DpToPt();
            SubTitle.PointSize = SubTitle.PointSize.DpToPt();
        }

        public NotiItemPage()
        {
            InitializeComponent();

            ApplyUnitSize();
        }
    }
}
