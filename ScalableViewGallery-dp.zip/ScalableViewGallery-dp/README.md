# How to launch the ScalableViewGallery app


## RPI4 with display

1. Connect the Local PC with RPI4 using SDB.
> * NOTE: If you connect the power of the RPI4 directly to the PC, the SDB is connected without having to connect to the SDB separately.
2. Run the app in Visual Studio. The app launches automatically after the installation is completed.


## Emulator

### Creates an emulator

#### How to make emulator using the latest platform image.

1) Download the latest image. <br/>
http://download.tizen.org/snapshots/tizen/unified/latest/images/emulator/tizen-headed-emulator32-wayland/

2) Download a script (make_emul_images_2partition.sh) to use to make the emulator image. <br/>
The script is placed in the first comment. Scroll down to the bottom of the page. <br/>
https://code.sec.samsung.net/confluence/pages/viewpage.action?spaceKey=GFX&title=How+to+use+VD+TV+emulator

2) Extract the .tar image and copy the *.img to the directory containing the script.
```
$ tar -xvzf tizen-unified_20211013.3_tizen-headed-emulator32-wayland.tar.gz
emulator-sysdata.img
emulator-rootfs.img
```
3) Run the script.
```
$ ./make_emul_images_2partition.sh
```
4) Use the result (emulimg.x86) as an image file. <br/>
![text](https://s3-us-west-1.amazonaws.com/tizenschool/255/resize_readme_1_1.PNG)

#### How to set the resolution and size

1) Enter the desired resolution and size. <br/>
![text](https://s3-us-west-1.amazonaws.com/tizenschool/255/resize_readme_2.PNG)


### Change kernel on emulator

There is a problem that the DPI value is not output properly on the emulator of the latest version of the Tizen Studio.
So you should change the kernel when you create a new emulator to get proper DPI value.

1) Download the kernel patch (bzImage.x86) in data directory and put it in the VM path you test. <br/>
```
C:\tizen-studio-data\emulator\vms\mc-1020-1
```

2) Open C:\tizen-studio-data\emulator\vms\mc-1020-1\vm_launch.conf <br/>
And modify the kernel path as follow: <br/>
```
kernel="C:\tizen-studio-data\emulator\vms\mc-1020-1\bzImage.${image_arch}"
```

> * NOTE: C:\tizen-studio\platforms\tizen-6.5\common\emulator\data\kernel <br/>
> This is the path of the original kernel. If you place the kernel patch here, the entire emulator will be changed the kernel. It is recommended to test only by putting it in the VM path being tested.


### Set the scale factor

1. Enter the shell of the target.

2. Create nui.sh with the desired scale factor value and reboot it.
```
mount -o remount rw /
echo export NUI_SCALING_FACTOR=2.1 > /etc/profile.d/nui.sh
cat /etc/profile.d/nui.sh
reboot
```

3. Confirm the changed value using the NUI sample app (org.tizen.example.Tizen.NUI.Samples-1.0.0) in data directory. <br/>
![text](https://s3-us-west-1.amazonaws.com/tizenschool/255/resize_readme_3.PNG)
> After installing the sample app, enter page 7 by swiping left.
> Click 'GraphicsTypeTest' to see information related to Dpi.

